import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.metrics import accuracy_score, classification_report
import matplotlib.pyplot as plt

def load_data():
    # Load the Iris dataset
    iris = load_iris()
    X = pd.DataFrame(iris.data, columns=iris.feature_names)
    y = pd.Series(iris.target, name="Species")
    print("\nFirst five rows of the Iris dataset:")
    print(pd.concat([X, y], axis=1).head())
    return X, y

def split_data(X, y):
    # Split the data into training and test sets (80% train, 20% test)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    return X_train, X_test, y_train, y_test

def build_decision_tree(X_train, y_train):
    # Build and train a decision tree classifier
    dt = DecisionTreeClassifier(random_state=42)
    dt.fit(X_train, y_train)
    print("\nDecision Tree Model trained successfully!")
    return dt

def prune_decision_tree(X_train, y_train):
    # Prune the decision tree to avoid overfitting
    dt_pruned = DecisionTreeClassifier(ccp_alpha=0.01, random_state=42)
    dt_pruned.fit(X_train, y_train)
    print("\nPruned Decision Tree Model trained successfully!")
    return dt_pruned

def random_forest(X_train, y_train):
    # Apply Random Forest to overcome overfitting
    rf = RandomForestClassifier(n_estimators=100, random_state=42)
    rf.fit(X_train, y_train)
    print("\nRandom Forest Model trained successfully!")
    return rf

def adaboost_decision_stumps(X_train, y_train):
    # Apply AdaBoost using Decision Stumps as base learners
    ada = AdaBoostClassifier(base_estimator=DecisionTreeClassifier(max_depth=1), n_estimators=50, random_state=42)
    ada.fit(X_train, y_train)
    print("\nAdaBoost Model trained successfully!")
    return ada

def evaluate_model(model, X_train, X_test, y_train, y_test, model_name):
    # Predictions and accuracy
    y_pred_train = model.predict(X_train)
    y_pred_test = model.predict(X_test)

    print(f"\n{model_name} - Training Accuracy: {accuracy_score(y_train, y_pred_train) * 100:.2f}%")
    print(f"{model_name} - Testing Accuracy: {accuracy_score(y_test, y_pred_test) * 100:.2f}%")
    
    print(f"\n{model_name} - Classification Report on Test Data:")
    print(classification_report(y_test, y_pred_test))

    # Plotting the decision tree if applicable
    if isinstance(model, DecisionTreeClassifier):
        plt.figure(figsize=(12, 8))
        plot_tree(model, feature_names=X_train.columns, class_names=load_iris().target_names, filled=True)
        plt.title(f"{model_name} - Decision Tree")
        plt.show()

def main():
    # Load data
    X, y = load_data()

    # Split data
    X_train, X_test, y_train, y_test = split_data(X, y)

    # Build and evaluate Decision Tree
    dt_model = build_decision_tree(X_train, y_train)
    evaluate_model(dt_model, X_train, X_test, y_train, y_test, "Decision Tree")

    # Prune and evaluate the Decision Tree
    pruned_dt_model = prune_decision_tree(X_train, y_train)
    evaluate_model(pruned_dt_model, X_train, X_test, y_train, y_test, "Pruned Decision Tree")

    # Apply and evaluate Random Forest
    rf_model = random_forest(X_train, y_train)
    evaluate_model(rf_model, X_train, X_test, y_train, y_test, "Random Forest")

    # Apply and evaluate AdaBoost
    ada_model = adaboost_decision_stumps(X_train, y_train)
    evaluate_model(ada_model, X_train, X_test, y_train, y_test, "AdaBoost with Decision Stumps")

if __name__ == "__main__":
    main()
