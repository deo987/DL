import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
from math import sqrt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, SimpleRNN

# Load the dataset
file_path = 'testset.csv'  # Update with your actual file path
df = pd.read_csv(file_path)

# Data Preprocessing
df.columns = df.columns.str.strip()  # Remove leading and trailing spaces from column names
df['_tempm'] = pd.to_numeric(df['_tempm'], errors='coerce')  # Ensure numeric type
df['_tempm'].fillna(df['_tempm'].median(), inplace=True)  # Fill NaN values

# Extract temperature values
temperature = df['_tempm'].values.reshape(-1, 1)

# Normalize the data
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_temp = scaler.fit_transform(temperature)

# Function to create sequences for RNN
def create_sequences(data, time_steps=60):
    X, y = [], []
    for i in range(len(data) - time_steps):
        X.append(data[i:i + time_steps, 0])
        y.append(data[i + time_steps, 0])
    return np.array(X), np.array(y)

# Hyperparameters
time_steps = 60  # Look-back period

# Split the data into training and testing sets
train_size = int(len(scaled_temp) * 0.8)
train_data = scaled_temp[:train_size]
test_data = scaled_temp[train_size:]

# Generate sequences for training and testing
X_train, y_train = create_sequences(train_data, time_steps)
X_test, y_test = create_sequences(test_data, time_steps)

# Reshape for RNN (samples, time steps, features)
X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))
X_test = X_test.reshape((X_test.shape[0], X_test.shape[1], 1))

# Build the RNN model
model = Sequential([
    SimpleRNN(50, return_sequences=False, input_shape=(time_steps, 1)),
    Dense(25),
    Dense(1)
])

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')

# Train the model with fewer epochs (e.g., 20 instead of 50)
model.fit(X_train, y_train, epochs=20, batch_size=32, validation_data=(X_test, y_test))

# Make predictions
predictions = model.predict(X_test)
predictions = scaler.inverse_transform(predictions)

# Calculate MSE and RMSE
mse = mean_squared_error(df['_tempm'][train_size + time_steps:], predictions)
rmse = sqrt(mse)
print(f'MSE: {mse:.4f}')
print(f'RMSE: {rmse:.4f}')

# Visualization: Actual vs Predicted
plt.figure(figsize=(10, 6))
plt.plot(df['_tempm'][train_size + time_steps:], label='Actual Temperature', color='blue')
plt.plot(np.arange(len(predictions)) + train_size + time_steps, predictions, label='Predicted Temperature', color='red')
plt.title('Temperature Prediction using RNN')
plt.xlabel('Time')
plt.ylabel('Temperature')
plt.legend()
plt.show()

# Save the model
model.save("rnn_weather_prediction.h5")
print("Model saved as rnn_weather_prediction.h5")
