import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM

# Load the dataset
file_path = 'testset.csv'  # Replace with your file path
df = pd.read_csv(file_path)

# Display basic information
print("Dataset loaded successfully")
print(df.head())

# Remove leading and trailing spaces from column names
df.columns = df.columns.str.strip()

# Check column names after trimming
print("Updated column names:")
print(df.columns)

# Data Preprocessing
# Fill missing values with the median of the column
df['_tempm'] = pd.to_numeric(df['_tempm'], errors='coerce')
df['_tempm'].fillna(df['_tempm'].median(), inplace=True)

# Convert the temperature column to a numpy array
temperature = df['_tempm'].values.reshape(-1, 1)

# Scale the temperature data between 0 and 1
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_temp = scaler.fit_transform(temperature)

# Create sequences for LSTM input
def create_sequences(data, time_steps=60):
    X, y = [], []
    for i in range(len(data) - time_steps):
        X.append(data[i:i + time_steps, 0])
        y.append(data[i + time_steps, 0])
    return np.array(X), np.array(y)

# Hyperparameters
time_steps = 60  # Look-back period

# Split the data into training and testing sets
train_size = int(len(scaled_temp) * 0.8)
train_data = scaled_temp[:train_size]
test_data = scaled_temp[train_size:]

# Generate sequences for training and testing
X_train, y_train = create_sequences(train_data, time_steps)
X_test, y_test = create_sequences(test_data, time_steps)

# Reshape the data for LSTM (samples, time steps, features)
X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))
X_test = X_test.reshape((X_test.shape[0], X_test.shape[1], 1))

# Build the LSTM model
model = Sequential([
    LSTM(50, return_sequences=True, input_shape=(time_steps, 1)),
    LSTM(50, return_sequences=False),
    Dense(25),
    Dense(1)
])

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')

# Train the model
model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test))

# Predict the temperature
predictions = model.predict(X_test)
predictions = scaler.inverse_transform(predictions)

# Plot actual vs predicted temperatures
plt.figure(figsize=(10, 6))
plt.plot(df['_tempm'][train_size + time_steps:], label='Actual Temperature', color='blue')
plt.plot(np.arange(len(predictions)) + train_size + time_steps, predictions, label='Predicted Temperature', color='red')
plt.title('Temperature Prediction using LSTM')
plt.xlabel('Time')
plt.ylabel('Temperature')
plt.legend()
plt.show()

# Save the model
model.save("lstm_weather_prediction.h5")
print("Model saved as lstm_weather_prediction.h5")
