import torch
import torchvision
from torchvision.models.detection import fasterrcnn_resnet50_fpn
from torchvision import transforms, datasets
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt

# Set device to CPU as you don't have a GPU
device = torch.device("cpu")
print(f"Using device: {device}")

# Fashion-MNIST class names
FASHION_MNIST_CLASSES = [
    "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat", 
    "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
]

# Transformation for input images
transform = transforms.Compose([
    transforms.Resize((224, 224)),  # Resize to fit the model input
    transforms.ToTensor()
])

# Load Fashion-MNIST dataset (inbuilt from torchvision)
fashion_mnist = datasets.FashionMNIST(
    root="./data", train=True, download=True, transform=transform
)

# DataLoader for batch processing
data_loader = DataLoader(fashion_mnist, batch_size=1, shuffle=True)

# Load the pre-trained Faster R-CNN model
model = fasterrcnn_resnet50_fpn(pretrained=True)
model.eval()
model.to(device)

# Generate a bounding box around the whole image
def create_bounding_box():
    return torch.tensor([[0, 0, 224, 224]], dtype=torch.float32)

# Visualization function
def visualize(image, boxes, labels):
    plt.figure(figsize=(6, 6))
    plt.imshow(image.squeeze(), cmap="gray")
    for i in range(len(boxes)):
        box = boxes[i].cpu().numpy()
        label = FASHION_MNIST_CLASSES[labels[i]]
        plt.gca().add_patch(plt.Rectangle((box[0], box[1]), box[2] - box[0], box[3] - box[1], 
                                          fill=False, color='red', linewidth=2))
        plt.text(box[0], box[1], label, color='yellow', fontsize=12, weight='bold')
    plt.axis('off')
    plt.show()

# Object detection on a single Fashion-MNIST image
def detect_objects(image, label):
    image = image.squeeze(0).to(device)  # Remove the batch dimension (from [1, C, H, W] to [C, H, W])

    # Simulated object detection (entire image as one object)
    boxes = create_bounding_box()
    labels = torch.tensor([label], dtype=torch.int64)

    # Make predictions using Faster R-CNN
    with torch.no_grad():
        predictions = model([image])

    # Replace predictions with the simulated bounding box and label
    predictions[0]['boxes'] = boxes
    predictions[0]['labels'] = labels
    predictions[0]['scores'] = torch.tensor([0.9])  # Arbitrary high confidence score

    # Visualize the result
    visualize(image.cpu(), predictions[0]['boxes'], predictions[0]['labels'])

# Test the object detection with a random image from the dataset
image, label = next(iter(data_loader))
detect_objects(image, label)
