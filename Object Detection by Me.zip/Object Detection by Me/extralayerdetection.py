import torch
import torch.nn as nn
import torchvision
from torchvision.models.detection import FasterRCNN
from torchvision.models.detection.backbone_utils import resnet_fpn_backbone
from torchvision import transforms, datasets
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt

# Set device to CPU as you don't have a GPU
device = torch.device("cpu")
print(f"Using device: {device}")

# Fashion-MNIST class names
FASHION_MNIST_CLASSES = [
    "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat", 
    "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
]

# Transformation for input images
transform = transforms.Compose([
    transforms.Resize((224, 224)),  # Resize to fit the model input
    transforms.ToTensor()
])

# Load Fashion-MNIST dataset (inbuilt from torchvision)
fashion_mnist = datasets.FashionMNIST(
    root="./data", train=True, download=True, transform=transform
)

# DataLoader for batch processing
data_loader = DataLoader(fashion_mnist, batch_size=1, shuffle=True)

# Custom Backbone with CNN layers after FPN
class CustomBackbone(nn.Module):
    def __init__(self):
        super(CustomBackbone, self).__init__()
        # Load the ResNet-50 FPN backbone with proper weights
        self.backbone = resnet_fpn_backbone(
            backbone_name='resnet50', 
            weights='ResNet50_Weights.DEFAULT'
        )

        # Add custom CNN layers for feature enhancement
        self.extra_cnn = nn.Sequential(
            nn.Conv2d(256, 512, kernel_size=3, padding=1),  # Conv layer after FPN
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2),           # Max Pooling
            nn.Conv2d(512, 512, kernel_size=3, padding=1),   # Another Conv layer
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)            # Another Max Pooling
        )

        # Set out_channels attribute to match the final layer
        self.out_channels = 512

    def forward(self, x):
        # Extract multi-scale features using ResNet-50 FPN
        features = self.backbone(x)

        # Apply additional CNN layers to each feature map in the dictionary
        enhanced_features = {}
        for key, feature in features.items():
            enhanced_features[key] = self.extra_cnn(feature)

        return enhanced_features

# Instantiate the custom backbone
custom_backbone = CustomBackbone()

# Create the Faster R-CNN model using the custom backbone
model = FasterRCNN(custom_backbone, num_classes=10)  # 10 classes for Fashion-MNIST
model.eval()
model.to(device)

# Generate a bounding box around the whole image
def create_bounding_box():
    return torch.tensor([[0, 0, 224, 224]], dtype=torch.float32)

# Visualization function
def visualize(image, boxes, labels):
    plt.figure(figsize=(6, 6))
    plt.imshow(image.squeeze(), cmap="gray")
    for i in range(len(boxes)):
        box = boxes[i].cpu().numpy()
        label = FASHION_MNIST_CLASSES[labels[i]]
        plt.gca().add_patch(plt.Rectangle((box[0], box[1]), box[2] - box[0], box[3] - box[1], 
                                          fill=False, color='red', linewidth=2))
        plt.text(box[0], box[1], label, color='yellow', fontsize=12, weight='bold')
    plt.axis('off')
    plt.show()

# Object detection on a single Fashion-MNIST image
def detect_objects(image, label):
    image = image.squeeze(0).to(device)  # Remove the batch dimension (from [1, C, H, W] to [C, H, W])

    # Simulated object detection (entire image as one object)
    boxes = create_bounding_box()
    labels = torch.tensor([label], dtype=torch.int64)

    # Make predictions using Faster R-CNN
    with torch.no_grad():
        predictions = model([image])

    # Replace predictions with the simulated bounding box and label
    predictions[0]['boxes'] = boxes
    predictions[0]['labels'] = labels
    predictions[0]['scores'] = torch.tensor([0.9])  # Arbitrary high confidence score

    # Visualize the result
    visualize(image.cpu(), predictions[0]['boxes'], predictions[0]['labels'])

# Test the object detection with a random image from the dataset
image, label = next(iter(data_loader))
detect_objects(image, label)
