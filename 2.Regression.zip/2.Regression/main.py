import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score

# 1. Load the California Housing dataset
data = fetch_california_housing()
X = pd.DataFrame(data.data, columns=data.feature_names)
y = pd.Series(data.target, name='Target')

# 2. Handle missing values (if any)
X.fillna(X.mean(), inplace=True)

# 3. Feature scaling (standardization)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ========== SIMPLE LINEAR REGRESSION ==========
# Use a single feature (e.g., 'AveRooms') for simple linear regression
X_simple = X[['AveRooms']]
X_train_simple, X_test_simple, y_train_simple, y_test_simple = train_test_split(
    X_simple, y, test_size=0.2, random_state=42)

simple_model = LinearRegression()
simple_model.fit(X_train_simple, y_train_simple)
y_pred_simple = simple_model.predict(X_test_simple)

# ========== MULTIPLE LINEAR REGRESSION ==========
X_train_multi, X_test_multi, y_train_multi, y_test_multi = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42)

multi_model = LinearRegression()
multi_model.fit(X_train_multi, y_train_multi)
y_pred_multi = multi_model.predict(X_test_multi)

# ========== EVALUATION FUNCTION ==========
def evaluate_model(y_true, y_pred, name):
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true, y_pred)
    print(f"\n{name} Results:")
    print(f"  Mean Squared Error (MSE): {mse:.2f}")
    print(f"  Root Mean Squared Error (RMSE): {rmse:.2f}")
    print(f"  R² Score: {r2:.2f}")

evaluate_model(y_test_simple, y_pred_simple, "Simple Linear Regression")
evaluate_model(y_test_multi, y_pred_multi, "Multiple Linear Regression")

# ========== VISUALIZATION ==========
# Plot for Simple Linear Regression
plt.figure(figsize=(8, 5))
plt.scatter(X_test_simple, y_test_simple, color='blue', alpha=0.5, label='Actual')
plt.plot(X_test_simple, y_pred_simple, color='red', linewidth=2, label='Predicted')
plt.xlabel('Average Rooms (AveRooms)')
plt.ylabel('House Value ($100k)')
plt.title('Simple Linear Regression - California Housing')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
