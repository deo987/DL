import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

def load_data():
    # Load the Iris dataset from sklearn
    iris = load_iris()
    X = pd.DataFrame(iris.data, columns=iris.feature_names)
    y = pd.Series(iris.target, name="Species")
    # Map numerical labels to their respective species names
    y = y.map({0: "Iris-setosa", 1: "Iris-versicolor", 2: "Iris-virginica"})
    
    print("\nFirst five rows of the Iris dataset:")
    print(pd.concat([X, y], axis=1).head())
    return X, y

def train_naive_bayes(X_train, y_train):
    # Initialize and train the Naive Bayes classifier
    model = GaussianNB()
    model.fit(X_train, y_train)
    print("\nModel trained successfully!\n")
    return model

def evaluate_model(model, X_test, y_test):
    # Predict the labels for the test data
    y_pred = model.predict(X_test)

    # Display predictions
    print("\nPredicted values:")
    print(y_pred)

    # Correct and incorrect predictions
    correct = (y_pred == y_test).sum()
    incorrect = (y_pred != y_test).sum()
    print(f"\nNumber of correct predictions: {correct}")
    print(f"Number of incorrect predictions: {incorrect}")

    # Model accuracy
    accuracy = accuracy_score(y_test, y_pred)
    print(f"\nAccuracy: {accuracy * 100:.2f}%")

    # Confusion matrix and classification report
    print("\nConfusion Matrix:")
    print(confusion_matrix(y_test, y_pred))

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

def main():
    # Load and preprocess the data
    X, y = load_data()

    # Split the data into training and testing sets (80% train, 20% test)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train and evaluate the model
    model = train_naive_bayes(X_train, y_train)
    evaluate_model(model, X_test, y_test)

if __name__ == "__main__":
    main()
