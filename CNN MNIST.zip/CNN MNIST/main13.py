import tensorflow as tf
from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import confusion_matrix, classification_report
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load and preprocess data
def load_data():
    (X_train, y_train), (X_test, y_test) = mnist.load_data()
    X_train = X_train.astype("float32") / 255.0
    X_test = X_test.astype("float32") / 255.0
    X_train = np.expand_dims(X_train, axis=-1)
    X_test = np.expand_dims(X_test, axis=-1)
    return (X_train, y_train), (X_test, y_test)

# Data augmentation
def augment_data(X_train):
    datagen = ImageDataGenerator(rotation_range=20, zoom_range=0.15, horizontal_flip=True)
    datagen.fit(X_train)
    return datagen

# Build model
def build_model():
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Flatten(),
        Dense(128, activation='relu'),
        Dense(10, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model

# Train model
def train_model(model, X_train, y_train, X_test, y_test, datagen=None):
    if datagen:
        history = model.fit(datagen.flow(X_train, y_train, batch_size=64), epochs=5, validation_data=(X_test, y_test))
    else:
        history = model.fit(X_train, y_train, epochs=5, batch_size=64, validation_data=(X_test, y_test))
    return history

# Evaluate model
def evaluate_model(model, X_test, y_test):
    y_pred = np.argmax(model.predict(X_test), axis=1)
    cm = confusion_matrix(y_test, y_pred)
    print("\nConfusion Matrix:")
    print(cm)
    sns.heatmap(cm, annot=True, cmap='Blues')
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.show()
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

# Plot accuracy
def plot_training_history(original_history, augmented_history):
    plt.figure(figsize=(12, 6))
    plt.plot(original_history.history['accuracy'], label='Original Training Accuracy')
    plt.plot(original_history.history['val_accuracy'], label='Original Validation Accuracy')
    plt.plot(augmented_history.history['accuracy'], label='Augmented Training Accuracy')
    plt.plot(augmented_history.history['val_accuracy'], label='Augmented Validation Accuracy')
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy")
    plt.title("Training and Validation Accuracy")
    plt.legend()
    plt.show()

# Main function
(X_train, y_train), (X_test, y_test) = load_data()
model = build_model()

# Train without augmentation
original_history = train_model(model, X_train, y_train, X_test, y_test)

# Train with augmentation
datagen = augment_data(X_train)
augmented_history = train_model(model, X_train, y_train, X_test, y_test, datagen)

# Evaluate and plot
evaluate_model(model, X_test, y_test)
plot_training_history(original_history, augmented_history)
