import yfinance as yf
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import SimpleRNN, Dense

# Step 1: Load NVIDIA (NVDA) stock data
data = yf.download('NVDA', start='2020-01-01', end='2024-12-31')
close_prices = data['Close'].values.reshape(-1, 1)

# Step 2: Scale the data
scaler = MinMaxScaler()
scaled_data = scaler.fit_transform(close_prices)

# Step 3: Create sequences (60 days history → 1 day prediction)
X, y = [], []
for i in range(60, len(scaled_data)):
    X.append(scaled_data[i-60:i])
    y.append(scaled_data[i])

X, y = np.array(X), np.array(y)

# Reshape input to Simple RNN expected format [samples, time_steps, features]
X = X.reshape((X.shape[0], X.shape[1], 1))

# Step 4: Build Simple RNN model
model = Sequential()
model.add(SimpleRNN(units=50, activation='tanh', input_shape=(X.shape[1], 1)))
model.add(Dense(1))

model.compile(optimizer='adam', loss='mean_squared_error')

# Step 5: Train the model
model.fit(X, y, epochs=10, batch_size=32)

# Step 6: Predict and plot
predicted = model.predict(X)
predicted_prices = scaler.inverse_transform(predicted)
actual_prices = scaler.inverse_transform(y)

# Step 7: Calculate evaluation metrics
mse = mean_squared_error(actual_prices, predicted_prices)
rmse = np.sqrt(mse)
mae = mean_absolute_error(actual_prices, predicted_prices)
r2 = r2_score(actual_prices, predicted_prices)

# Print evaluation metrics
print(f"Mean Squared Error (MSE): {mse}")
print(f"Root Mean Squared Error (RMSE): {rmse}")
print(f"Mean Absolute Error (MAE): {mae}")
print(f"R² Score: {r2}")

# Step 8: Plot results
plt.figure(figsize=(10,6))
plt.plot(actual_prices, label='Actual Price')
plt.plot(predicted_prices, label='Predicted Price')
plt.title("NVIDIA Stock Price Prediction using Simple RNN")
plt.xlabel("Days")
plt.ylabel("Price")
plt.legend()
plt.show()
