import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# Step a: Load your dataset
df = pd.read_csv("Iris.csv")

# Drop non-numeric columns (Id and Species)
X = df.drop(['Id', 'Species'], axis=1)

# Step a: Standardize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Step b: Perform PCA
pca = PCA()
X_pca = pca.fit_transform(X_scaled)

# Step c: Scree Plot (Explained Variance)
plt.figure(figsize=(8, 5))
plt.plot(range(1, len(pca.explained_variance_ratio_)+1),
         pca.explained_variance_ratio_.cumsum(),
         marker='o', linestyle='--')
plt.title('Scree Plot')
plt.xlabel('Number of Principal Components')
plt.ylabel('Cumulative Explained Variance')
plt.grid(True)
plt.show()

# Step d: 2D Visualization using first 2 principal components
pca_2d = PCA(n_components=2)
X_pca_2d = pca_2d.fit_transform(X_scaled)

plt.figure(figsize=(7, 5))
species = df['Species'].unique()
colors = ['red', 'green', 'blue']

for sp, color in zip(species, colors):
    plt.scatter(X_pca_2d[df['Species'] == sp, 0],
                X_pca_2d[df['Species'] == sp, 1],
                label=sp, color=color)

plt.title('PCA - 2D Visualization of Iris Dataset')
plt.xlabel('PC1')
plt.ylabel('PC2')
plt.legend()
plt.grid(True)
plt.show()
